package com.example.diego.genius;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;



public class Genius extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genius);
        Lacuna1= (TextView) findViewById(R.id.Lacuna1);
        Lacuna2= (TextView) findViewById(R.id.Lacuna2);
        Lacuna3= (TextView) findViewById(R.id.Lacuna3);
        Lacuna4= (TextView) findViewById(R.id.Lacuna4);
        Off= (ImageView) findViewById(R.id.off);
        Pontuacao= (TextView) findViewById(R.id.Pontuacao);
        Proxima= (TextView)findViewById(R.id.Proxima);
        Score =(TextView)findViewById(R.id.score);
        accion = new acao();
        PiscarAm = new PiscarAmarelo();
        PiscarAz = new PiscarAzul();
        PiscarVlh = new PiscarVermelho();
        PiscarVrd = new PiscarVerde();
        intervalo = new Temposegundos();
        restart= (Button) findViewById(R.id.Start);

        // ler o arquivo e mudar o placar de Score

        Score.setText(""+Ler());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_genius, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // variaveis e objetos

    private int contador=0,contador2=0,cont3=0,pontos=1;
    private long velocidade = 450 , velocidade2=200,velocidade3=1500;
    private Random gerador = new Random();
    private Timer tempo = new Timer();
    private Timer tempo3 = new Timer();
    private Timer tempo4 = new Timer();
    private int[] vetor = new int[200];
    private int Cont=0,Cont2=0,contador3=0,i,indicadorDeFinal=1 , contadorDeControle=0,p;
    private TextView Lacuna1; // vermelhor
    private TextView Lacuna2; // verde
    private TextView Lacuna3; // azul
    private TextView Lacuna4; // amarelo
    private ImageView Off;
    private TextView Pontuacao;
    private TextView Proxima;
    private TextView Score;
    private AlertDialog mostrar;
    private acao accion;
    private PiscarVermelho PiscarVlh;
    private PiscarVerde PiscarVrd;
    private PiscarAmarelo PiscarAm;
    private PiscarAzul PiscarAz;
    private Temposegundos intervalo;
    private Button restart;



    // contadorDeControle serve para garantir a piscagem dos quadrados, sem ele , quadrados repetidos nao pisca

    // fim de variaveis


    public void BotaoStart(View view){

        contador++;
        restart.setText("Reiniciar");
        if(contador==1){

            EscolherPosicoes();
            accion = new acao();// esse
            tempo = new Timer(); // esse

            tempo.schedule(accion,100,velocidade);
        }

        else{
            tempo.cancel();
            Reiniciar();

        }

    }

    public void coresPadrao() {

        Lacuna1.setBackgroundColor(Color.parseColor("#ff8777"));
        Lacuna2.setBackgroundColor(Color.parseColor("#a3ff99"));
        Lacuna3.setBackgroundColor(Color.parseColor("#7b8cff"));
        Lacuna4.setBackgroundColor(Color.parseColor("#feffa1"));
        Off.setBackgroundResource(R.drawable.off1);

    }

    private void Reiniciar(){
        contador2=0;
        contador3=0;
        coresPadrao();
        pontos=1;
        Pontuacao.setText("0");
        cont3=0;
        Cont=0;
        Cont2=0;
        EscolherPosicoes();
        tempo=new Timer();
        accion=new acao();
        indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
        tempo3.cancel(); // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
        tempo.schedule(accion, 300, velocidade);


    }

    private void ConfirmarJogada(){

        intervalo=new Temposegundos(); // esse
        tempo4= new Timer();           //esse
        Proxima.setText("   Aguarde");
        tempo4.schedule(intervalo, 0, velocidade3);




    }

    private void EscolherPosicoes(){
        for(p = 0 ; p<200 ; p++){
            i = gerador.nextInt(4);
            vetor[p] = i;

        }
    }


// metodos das lacunas

    public void vermelho(View view)
    {

        if(indicadorDeFinal==0)
        {
                        indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP

                        //piscar
                        tempo3 = new Timer();   // esse
                        PiscarVlh=new PiscarVermelho();// esse
                        tempo3.schedule(PiscarVlh,0,velocidade2);
                        Off.setBackgroundResource(R.drawable.red);
                        Log.i("teste","Vermelho");

                    if(vetor[Cont2] == 0)
                    {

                        if(Cont2==Cont)
                        {
                            ConfirmarJogada();
                        }
                        else
                        {
                            Cont2++;
                            indicadorDeFinal=0; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                        }

                    }
            else
                    {
                         mensagem();

                    }
        }
    }

    public void verde(View view)
    {
        if(indicadorDeFinal==0)
        {     indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
            //piscar
            tempo3 =new Timer();
            PiscarVrd =new PiscarVerde();
           tempo3.schedule(PiscarVrd,0,velocidade2);
           Off.setBackgroundResource(R.drawable.green);
            Log.i("teste","Verde");
            if(vetor[Cont2] ==1)
            {

                if(Cont2==Cont)
                {
                    ConfirmarJogada();

                }
                else
                {
                    Cont2++;
                    indicadorDeFinal=0; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                }

            }
            else
            {
               mensagem();

            }
        }

    }

    public void azul(View view)
    {
        if(indicadorDeFinal==0)
        {
            indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
            //piscar
            tempo3=new Timer();
            PiscarAz=new PiscarAzul();
            tempo3.schedule(PiscarAz,0,velocidade2);
            Off.setBackgroundResource(R.drawable.blue1);
            Log.i("teste","Azul");

            if(vetor[Cont2] == 2)
            {

                if(Cont2==Cont)
                {
                    ConfirmarJogada();

                }
                else
                {
                    Cont2++;
                    indicadorDeFinal=0; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                }

            }
            else
            {
              mensagem();

            }
        }
    }

    public void amarelo(View view)
    {
        if(indicadorDeFinal==0)
        {     indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
            //piscar
            tempo3=new Timer();
            PiscarAm=new PiscarAmarelo();
            tempo3.schedule(PiscarAm,0,velocidade2);
            Off.setBackgroundResource(R.drawable.yellow);
            Log.i("teste","Amarelo");

            if(vetor[Cont2] == 3)
            {

                if(Cont2==Cont)
                {
                    ConfirmarJogada();

                }
                else
                {
                    Cont2++;
                    indicadorDeFinal=0;//COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                }

            }
            else
            {
               mensagem();

            }
        }

    }



    // mensagem de fim de jogo

    public void mensagem(){

        AlertDialog.Builder mensage = new AlertDialog.Builder(this);
        mensage.setTitle("  :C  ");
        mensage.setMessage("Jogada Errado");
        mensage.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Reiniciar();
            }
        });

        mostrar = mensage.create();
        mostrar.show();


    }

    // analisando pontuaçao para poder gravar ou não no arquivo

    public void AnalisarPontos(int Ponto , int PontoGravado){
        if(Ponto>PontoGravado){
            Salvar(Ponto);
            Score.setText(""+Ponto);
        }
    }


    // getteres e setteres

    public TextView getLacuna1() {return Lacuna1; }

    public void setLacuna1(TextView lacuna1) {Lacuna1 = lacuna1; }

    public TextView getLacuna2() {return Lacuna2;}

    public void setLacuna2(TextView lacuna2) { Lacuna2 = lacuna2; }

    public TextView getLacuna3() {return Lacuna3;}

    public void setLacuna3(TextView lacuna3) {Lacuna3 = lacuna3;}

    public TextView getLacuna4() {return Lacuna4;}

    public void setLacuna4(TextView lacuna4) { Lacuna4 = lacuna4;}

    public TextView getPontuacao() { return Pontuacao;}

    public void setPontuacao(TextView pontuacao) {Pontuacao = pontuacao; }

    public TextView getProxima() { return Proxima; }

    public void setProxima(TextView proxima) { Proxima = proxima;}

    // fim de getteres e setteres




    class acao extends TimerTask{

        public void run(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {


                    coresPadrao();
                    contadorDeControle++;

                    if(contadorDeControle % 2 ==0 )

                    {
                        indicadorDeFinal++;// variavel de controle para o usuario não clicar junto quando estiver em execuçao esse comando
                        if(contador2<=Cont)
                        {
                            switch (vetor[contador2])
                                {
                                case 0:

                                    Lacuna1.setBackgroundColor(Color.parseColor("#ff0001"));
                                    Off.setBackgroundResource(R.drawable.red);
                                    break;

                                case 1:

                                    Lacuna2.setBackgroundColor(Color.parseColor("#26ff09"));
                                    Off.setBackgroundResource(R.drawable.green);
                                    break;

                                case 2:

                                    Lacuna3.setBackgroundColor(Color.parseColor("#101bff"));
                                    Off.setBackgroundResource(R.drawable.blue1);
                                    break;

                                case 3:

                                    Lacuna4.setBackgroundColor(Color.parseColor("#fff006"));
                                    Off.setBackgroundResource(R.drawable.yellow);
                                    break;
                            }

                            contador2++;
                        }

                        else
                        {
                            if(contador2>Cont)
                            {
                                contador2=0;
                                indicadorDeFinal=0;
                                contadorDeControle=0;
                                tempo.cancel();
                            }
                        }
                    }

                }
            });
}
        }

    class PiscarVermelho extends TimerTask{

    public void run(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                coresPadrao();
                contador3++;
                indicadorDeFinal=1; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                if(contador3==1)
                {
                    Lacuna1.setBackgroundColor(Color.parseColor("#ff0001"));
                }

                else
                {   indicadorDeFinal=0; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                    contador3=0;
                    tempo3.cancel();
                }

            }
        });
    }
}

    class PiscarVerde extends TimerTask{

    public void run(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                coresPadrao();
                contador3++;
                indicadorDeFinal=1; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                if(contador3==1)
                {
                    Lacuna2.setBackgroundColor(Color.parseColor("#26ff09"));
                }

                else
                {   indicadorDeFinal=0; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                    contador3=0;
                    tempo3.cancel();
                }

            }
        });
    }
}

    class PiscarAzul extends TimerTask{

    public void run(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                coresPadrao();
                contador3++;
                indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                if(contador3==1)
                {
                    Lacuna3.setBackgroundColor(Color.parseColor("#101bff"));
                }

                else
                {   indicadorDeFinal=0; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                    contador3=0;
                    tempo3.cancel();
                }

            }
        });
    }
}

    class PiscarAmarelo extends TimerTask{

    public void run(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                coresPadrao();
                contador3++;
                indicadorDeFinal=1; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                if(contador3==1)
                {
                    Lacuna4.setBackgroundColor(Color.parseColor("#fff006"));
                }

                else
                {   indicadorDeFinal=0; //COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                    contador3=0;
                    tempo3.cancel();
                }

            }
        });
    }
}

    class Temposegundos extends TimerTask {
        public void run(){
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    cont3++;
                    if(cont3==2){
                        AnalisarPontos(pontos,Ler());
                        Proxima.setText("        ");
                        Pontuacao.setText(" " + pontos);
                        pontos++;
                        Cont2=0;
                        Cont++;



                    }
                    if(cont3==3) {
                        cont3=0;
                        tempo=new Timer();
                        accion = new acao();
                        tempo.schedule(accion, 0, velocidade);
                        indicadorDeFinal=0; // COLOCADA PARA CONTROLE DE VELOCIDADE DO CLIQUE PARA NÃO ENTRAR EM LOOP
                     tempo4.cancel();
                    }
                }
            });
        }
    }


    // salvar e ler Pontuacao

    // salvar
    private void Salvar(int recorde){ // ta passando como parametro os pontos

        // criar um arquivo ou abrir

        SharedPreferences salvarELer = getSharedPreferences("pontuacao" , Context.MODE_PRIVATE);

        // editor

        SharedPreferences.Editor editar = salvarELer.edit();

        editar.putInt("ponts" , recorde);

        //gravar

        editar.commit();

    }

    // ler
    private int Ler(){

        SharedPreferences salvarELer = getSharedPreferences("pontuacao" , Context.MODE_PRIVATE);

        // pegando os pontos salvos

      int PegarSalvo=   salvarELer.getInt("ponts" ,0);

      return PegarSalvo;
    }
}
